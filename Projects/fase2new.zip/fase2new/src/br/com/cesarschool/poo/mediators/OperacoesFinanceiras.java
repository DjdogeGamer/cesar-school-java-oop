package br.com.cesarschool.poo.mediators;

public enum OperacoesFinanceiras {
	CREDITAR, DEBITAR
}
