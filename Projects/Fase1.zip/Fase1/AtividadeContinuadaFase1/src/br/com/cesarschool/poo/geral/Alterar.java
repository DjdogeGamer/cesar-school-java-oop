package br.com.cesarschool.poo.geral;

public enum Alterar {
	ALTERAR_DATA, ENCERRAR_CONTA, BLOQUEAR_CONTA, ATIVAR_CONTA;
}
