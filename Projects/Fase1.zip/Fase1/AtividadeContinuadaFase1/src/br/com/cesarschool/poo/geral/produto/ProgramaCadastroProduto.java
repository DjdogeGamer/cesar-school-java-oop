package br.com.cesarschool.poo.geral.produto;

public class ProgramaCadastroProduto {

	public static void main(String[] args) {
		TelaProduto tela = new TelaProduto();
		tela.executaTela();
	}
}
 